#include "stdafx.h"
#include "MyGame.h"

CMyGame::CMyGame(void) :
	background(400, 300, "background.bmp", CColor::Black(), 0),
	background2(400, 300, "background2.bmp", CColor::Black(), 0),
	background3(400, 300, "background3.bmp", CColor::Black(), 0),
	startScreen(400, 300, "StartScreen.bmp", CColor::Black(), 0)
{
}

CMyGame::~CMyGame(void)
{
}

void CMyGame::OnUpdate()
{
	if (IsMenuMode() || IsGameOverMode()) return;

	long t = GetTime();

	// sprites update
	player.Update(t);
	for (CSprite* shot : shotList) shot->Update(t);
	for (CSprite* shot : enemyshotList) shot->Update(t);
	for (CSprite* enemy : enemyList) enemy->Update(t);
	for (CSprite* enemy : ufoList) enemy->Update(t);
	for (CSprite* enemy : bossList) enemy->Update(t);
	for (CSprite* explosion : explosionList) explosion->Update(t);
	for (CSprite* heart : heartList) heart->Update(t);

	// countdown to start a new level
	if (countdown > 0)
	{
		countdown -= 2;
		player.SetSpeed(0);
	}
	else player.SetSpeed(180);

	// change level if all enemies killed
	if (enemyleft <= 0) {
		level++;
		if (level == 2) SetupLevel2();
		if (level == 3) SetupLevel3();
		if (level == 4) {
			gamewon = true;
			winSound.Play("win.wav");
			GameOver();
		}
	}

	if (!countdown > 0) {
		PlayerControl();
		HeartControl();
		EnemyControl();
		UfoControl();
		BossControl();
	}
}

void CMyGame::PlayerControl()
{
	if (lives <= 0) GameOver();

	// gameover if player out of screen
	if (player.GetY() < 0 || player.GetY() > 600 || player.GetX() > 800 || player.GetX() < 0) GameOver();

	// shot-enemy HitTest
	for (CSprite* shot : shotList)
	{
		if (shot->GetY() < 0 || shot->GetY() > 600 || shot->GetX() > 800 || shot->GetX() < 0) shot->Delete(); // shot deleted if out of screen
		for (CSprite* enemy : enemyList) {
			if (shot->HitTest(enemy, 1))
			{
				shot->Delete();
				enemy->Delete();
				CSprite* explosion = new CSprite(enemy->GetX(), enemy->GetY(), 0, 0, GetTime());
				explosion->AddImage("explosion3A.bmp", "explode", 3, 1, 0, 0, 2, 0, CColor::Black());
				explosion->SetAnimation("explode", 5);
				explosion->Die(500);
				explosionList.push_back(explosion);
				explosionSound.Play("explosion.wav");
				enemyleft--;
			}
		}
	}
	shotList.delete_if(deleted);
	enemyList.delete_if(deleted);
	explosionList.delete_if(deleted);

	// shot-ufo HitTest
	for (CSprite* shot : shotList)
	{
		for (CSprite* enemy : ufoList) {
			if (shot->HitTest(enemy, 1))
			{
				shot->Delete();
				enemy->Delete();
				CSprite* explosion = new CSprite(enemy->GetX(), enemy->GetY(), 0, 0, GetTime());
				explosion->AddImage("explosion5x5.bmp", "explode", 5, 5, 0, 0, 4, 4, CColor::Black());
				explosion->SetAnimation("explode", 50);
				explosion->Die(500);
				explosionList.push_back(explosion);
				explosionSound.Play("explosion.wav");
				enemyleft--;
			}
		}
	}
	shotList.delete_if(deleted);
	ufoList.delete_if(deleted);
	explosionList.delete_if(deleted);

	// shot-boss HitTest
	for (CSprite* shot : shotList)
	{
		for (CSprite* enemy : bossList) {
			if (shot->HitTest(enemy, 1))
			{
				shot->Delete();
				CSprite* explosion = new CSprite(enemy->GetX(), enemy->GetY(), 0, 0, GetTime());
				explosion->AddImage("explosion5x5.bmp", "explode", 5, 5, 0, 0, 4, 4, CColor::Black());
				explosion->SetAnimation("explode", 25);
				explosion->Die(1000);
				explosionList.push_back(explosion);
				explosionSound.Play("explosion.wav");
				bosslives--;
			}
		}
	}
	shotList.delete_if(deleted);
	bossList.delete_if(deleted);
	explosionList.delete_if(deleted);
}

void CMyGame::HeartControl() {
	// heart random spawning ~10 seconds
	if (rand() % 600 == 0) {
		CSprite* newheart = new CSprite(float(rand() % 800), float(rand() % 600), "heart.bmp", CColor::Black(), GetTime());
		newheart->SetDirection(player.GetX() - newheart->GetX(), player.GetY() - newheart->GetY());
		newheart->SetSpeed(8);
		newheart->Die(8000); // heart disappears after 8 seconds
		heartList.push_back(newheart);
	}

	// heart-player HitTest, player lives increase
	for (CSprite* heart : heartList) {
		if (player.HitTest(heart, 1))
		{
			lives++;
			heart->Delete();
			heartSound.Play("heart.wav");
		}
	}
	heartList.delete_if(deleted);
}

void CMyGame::EnemyControl()
{
	// enemy-player HitTest
	for (CSprite* enemy : enemyList) {
		if (player.HitTest(enemy, 1))
		{
			lives--;
			enemyleft--;
			enemy->Delete();
			CSprite* explosion = new CSprite(player.GetX(), player.GetY(), 0, 0, GetTime());
			explosion->AddImage("explosion3A.bmp", "explode", 3, 1, 0, 0, 2, 0, CColor::Black());
			explosion->SetAnimation("explode", 5);
			explosion->Die(500);
			explosionList.push_back(explosion);
			explosionSound.Play("explosion.wav");
		}
	}
	enemyList.delete_if(deleted);
	explosionList.delete_if(deleted);

	// enemy random spawning ~2.5 seconds
	if (rand() % 150 == 0 && level < 3) {
		CSprite* newenemy = new CSprite(float(rand() % 800), float(rand() % 600), "enemy.bmp", CColor::Black(), GetTime());
		newenemy->SetDirection(player.GetX() - newenemy->GetX(), player.GetY() - newenemy->GetY());
		newenemy->SetSpeed(80);
		if (level == 1)
			newenemy->LoadAnimation("enemy3A.bmp", "fly", CSprite::Sheet(3, 1).Row(0).From(0).To(2), CColor::Black());
		else if (level == 2)
			newenemy->LoadAnimation("enemy3A_red.bmp", "fly", CSprite::Sheet(3, 1).Row(0).From(0).To(2), CColor::Black());
		newenemy->SetAnimation("fly", 5);
		enemyList.push_back(newenemy);
	}

	// setting enemies direction
	for (CSprite* enemy : enemyList)
		enemy->SetDirection(player.GetX() - enemy->GetX(), player.GetY() - enemy->GetY());


}

void CMyGame::UfoControl() {

	// ufo-player HitTest
	for (CSprite* enemy : ufoList) {
		if (player.HitTest(enemy, 1))
		{
			lives--;
			enemyleft--;
			enemy->Delete();
			CSprite* explosion = new CSprite(player.GetX(), player.GetY(), 0, 0, GetTime());
			explosion->AddImage("explosion5x5.bmp", "explode", 5, 5, 0, 0, 4, 4, CColor::Black());
			explosion->SetAnimation("explode", 25);
			explosion->Die(1000);
			explosionList.push_back(explosion);
			explosionSound.Play("explosion.wav");
		}
	}
	ufoList.delete_if(deleted);
	explosionList.delete_if(deleted);

	// ufo random spawning ~3.33 seconds
	if (level == 2 && rand() % 200 == 0) {
		CSprite* newenemy = new CSprite(float(rand() % 800), float(rand() % 600), "ufo.bmp", CColor::White(), GetTime());
		newenemy->SetDirection(player.GetX() - newenemy->GetX(), player.GetY() - newenemy->GetY());
		newenemy->SetSpeed(80);
		ufoList.push_back(newenemy);
	}

	// ufo shooting
	for (CSprite* enemy : ufoList) {
		enemy->SetDirection(player.GetX() - enemy->GetX(), player.GetY() - enemy->GetY()); 	// setting ufo direction
		if (rand() % 150 == 0) {
			CSprite* newShot = new CSprite(enemy->GetX(), enemy->GetY(), "shot.bmp", CColor::White(), GetTime());
			newShot->SetMotion(0, 250);
			newShot->SetDirection(enemy->GetDirection());
			enemyshotList.push_back(newShot);
			shotSound.Play("shot.wav");
		}
	}

	// ufoshot-player HitTest
	for (CSprite* shot : enemyshotList)
	{
		if (shot->GetY() < 0 || shot->GetY() > 600 || shot->GetX() > 800 || shot->GetX() < 0) shot->Delete(); // enemyshot deleted if out of screen
		if (shot->HitTest(&player, 1))
		{
			shot->Delete();
			lives--;
			CSprite* explosion = new CSprite(player.GetX(), player.GetY(), 0, 0, GetTime());
			explosion->AddImage("explosion5x5.bmp", "explode", 5, 5, 0, 0, 4, 4, CColor::Black());
			explosion->SetAnimation("explode", 25);
			explosion->Die(1000);
			explosionList.push_back(explosion);
			explosionSound.Play("explosion.wav");
		}
	}
	enemyshotList.delete_if(deleted);
	explosionList.delete_if(deleted);
}

void CMyGame::BossControl() {

	// boss-player HitTest, player lives decrease
	for (CSprite* enemy : bossList) {
		if (player.HitTest(enemy, 1))
		{
			lives--;
			bosslives--;
			CSprite* explosion = new CSprite(player.GetX(), player.GetY(), 0, 0, GetTime());
			explosion->AddImage("explosion5x5.bmp", "explode", 5, 5, 0, 0, 4, 4, CColor::Black());
			explosion->SetAnimation("explode", 25);
			explosion->Die(1000);
			explosionList.push_back(explosion);
			explosionSound.Play("explosion.wav");
		}
	}
	explosionList.delete_if(deleted);

	// boss shooting
	for (CSprite* enemy : bossList) {
		enemy->SetDirection(player.GetX() - enemy->GetX(), player.GetY() - enemy->GetY()); // setting boss direction
		if (rand() % 40 == 0) {
			CSprite* newShot = new CSprite(enemy->GetX(), enemy->GetY(), "shot.bmp", CColor::White(), GetTime());
			newShot->SetMotion(0, 250);
			newShot->SetDirection(enemy->GetDirection());
			enemyshotList.push_back(newShot);
			shotSound.Play("shot.wav");
		}
	}

	// boss dies if bosslives finish
	for (CSprite* enemy : bossList) {
		if (bosslives <= 0) {
			enemy->Delete();
			enemyleft--;
		}
	}
	bossList.delete_if(deleted);
}

void CMyGame::OnDraw(CGraphics* g)
{
	// draw start screen and the selected level when in menu mode
	if (IsMenuMode()) {
		startScreen.Draw(g);
		*g << font(50) << color(CColor::Red()) << xy(500, 150) << "Level " << level;
		*g << font(18) << color(CColor::Red()) << xy(520, 120) << "F1 for level 1";
		*g << font(18) << color(CColor::Red()) << xy(520, 95) << "F2 for level 2";
		*g << font(18) << color(CColor::Red()) << xy(520, 70) << "F3 for level 3";
		*g << font(18) << color(CColor::Yellow()) << xy(80, 260) << "Mouse to move";
		*g << font(18) << color(CColor::Yellow()) << xy(80, 230) << "Left Ctrl to shoot";
		*g << font(18) << color(CColor::Yellow()) << xy(80, 200) << "Space to pause";
		*g << font(18) << color(CColor::Yellow()) << xy(80, 170) << "F2 to restart";
		return;
	}

	// draw sprites
	if (level == 1)
		background.Draw(g);
	else if (level == 2)
		background2.Draw(g);
	else if (level >= 3)
		background3.Draw(g);
	for (CSprite* shot : shotList) shot->Draw(g);
	for (CSprite* shot : enemyshotList) shot->Draw(g);
	for (CSprite* enemy : enemyList) enemy->Draw(g);
	for (CSprite* explosion : explosionList) explosion->Draw(g);
	for (CSprite* enemy : ufoList) enemy->Draw(g);
	for (CSprite* enemy : bossList) enemy->Draw(g);
	for (CSprite* heart : heartList) heart->Draw(g);
	player.Draw(g);


	// draw lives and N of enemies left
	*g << font(28) << color(CColor::Red()) << xy(10, 570) << "Lives: " << lives;
	*g << font(28) << color(CColor::Red()) << xy(580, 570) << "Enemies left: " << enemyleft;
	
	// debugging stuff
	/*
	*g << font(28) << color(CColor::Red()) << xy(600, 540) << "plShot: " << shotList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 510) << "enemy: " << enemyList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 480) << "enShot: " << enemyshotList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 450) << "ufo: " << ufoList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 420) << "explosion: " << explosionList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 390) << "boss: " << bossList.size();
	*g << font(28) << color(CColor::Red()) << xy(600, 360) << "heart: " << heartList.size();
	*/

	// draw boss lives over it
	if (level == 3) 
		for (CSprite* enemy : bossList) 
			*g << font(20) << color(CColor::Red()) << xy(enemy->GetX(), enemy->GetY() +40) << "Lives: " << bosslives;

	// print "game over" (or "game won" if game has been won) at the centre of the screen
	if (IsGameOverMode())
		if (gamewon) 
			*g << font(46) << color(CColor::Green()) << vcenter << center << " MISSION COMPLETE ";
		else
			*g << font(46) << color(CColor::Red()) << vcenter << center << " GAME OVER ";

	// print level at start level
	if (countdown > 0)
		*g << font(150) << color(CColor::Blue(2 * countdown)) << vcenter << center << "Level " << level;

}

/////////////////////////////////////////////////////
// Game Life Cycle

// one time initialisation
void CMyGame::OnInitialize()
{
	// add player animated sequences 
	player.LoadAnimation("spaceship.bmp", "spaceship", CSprite::Sheet(3, 1).Row(0).From(0).To(2), CColor::Black());
	player.SetAnimation("spaceship", 3);
	player.SetDirection(90);

	// play background music
	backgroundSound.Play("music.wav", -1);

}

// called at the start of a new game
void CMyGame::OnDisplayMenu()
{
	// default level
	level = 1;
}

// called when Game Mode entered
void CMyGame::OnStartGame()
{
	// reset every variable
	countdown = 0;
	gamewon = false;
	lives = 5;
	bossList.delete_all();
	explosionList.delete_all();
	shotList.delete_all();
	enemyList.delete_all();
	enemyshotList.delete_all();
	ufoList.delete_all();
	heartList.delete_all();

	if (level == 1)
		SetupLevel1();
	if (level == 2)
		SetupLevel2();
	if (level == 3)
		SetupLevel3();
}

// called at the beginning of level 1
void CMyGame::SetupLevel1()
{
	// reset every variable
	gamewon = false;
	lives = 5;
	countdown = 150;
	enemyleft = 20;
	bossList.delete_all();
	explosionList.delete_all();
	shotList.delete_all();
	enemyList.delete_all();
	enemyshotList.delete_all();
	ufoList.delete_all();
	heartList.delete_all();

	player.SetPosition(400, 300);
	player.SetSpeed(180);

}

// called at the beginning of level 2
void CMyGame::SetupLevel2()
{
	// reset every variable
	gamewon = false;
	lives = 5;
	countdown = 150;
	enemyleft = 25;
	bossList.delete_all();
	explosionList.delete_all();
	shotList.delete_all();
	enemyList.delete_all();
	enemyshotList.delete_all();
	ufoList.delete_all();
	heartList.delete_all();

	player.SetPosition(400, 300);
	player.SetSpeed(180);
}

void CMyGame::SetupLevel3()
{
	// reset every variable
	gamewon = false;
	lives = 5;
	bosslives = 30;
	countdown = 150;
	enemyleft = 1;
	bossList.delete_all();
	explosionList.delete_all();
	shotList.delete_all();
	enemyList.delete_all();
	enemyshotList.delete_all();
	ufoList.delete_all();
	heartList.delete_all();

	player.SetPosition(100, 100);
	player.SetSpeed(180);

	// boss spawning
	CSprite* boss = new CSprite(400, 300, "boss.bmp", CColor::White(), GetTime());
	boss->SetDirection(player.GetX() - boss->GetX(), player.GetY() - boss->GetY());
	boss->SetSpeed(40);
	bossList.push_back(boss);

}

// called when Game is Over
void CMyGame::OnGameOver()
{
}

// one time termination code
void CMyGame::OnTerminate()
{
}

/////////////////////////////////////////////////////
// Keyboard Event Handlers

void CMyGame::OnKeyDown(SDLKey sym, SDLMod mod, Uint16 unicode)
{
	if (sym == SDLK_F4 && (mod & (KMOD_LALT | KMOD_RALT)))
		StopGame();
	if (sym == SDLK_SPACE)
		PauseGame();
	if (!IsMenuMode() && sym == SDLK_F2)
		NewGame();

	// level selection
	if (IsMenuMode())
	{
		if (sym == SDLK_F1)
			level = 1;
		if (sym == SDLK_F2)
			level = 2;
		if (sym == SDLK_F3)
			level = 3;
	}

	// Lctrl to shoot
	if (sym == SDLK_LCTRL && !(IsMenuMode() || IsGameOver() || IsPaused())) {
		CSprite* newShot = new CSprite(player.GetX(), player.GetY(), "shot2.bmp", CColor::White(), GetTime());
		// set the motion of the new shot sprite
		newShot->SetMotion(0, 500);
		newShot->SetDirection(player.GetDirection());
		// add the shot sprite to the list
		shotList.push_back(newShot);
		// play shot sound
		shotSound.Play("shot.wav");
	}

}

void CMyGame::OnKeyUp(SDLKey sym, SDLMod mod, Uint16 unicode)
{

}


/////////////////////////////////////////////////////
// Mouse Events Handlers

void CMyGame::OnMouseMove(Uint16 x, Uint16 y, Sint16 relx, Sint16 rely, bool bLeft, bool bRight, bool bMiddle)
{
	// player follows mouse cursor
	if (!(IsMenuMode() || IsGameOver() || IsPaused())) {
		player.SetDirection(x - player.GetX(), y - player.GetY());
		player.SetRotation(player.GetDirection() - 90);
	}
}


void CMyGame::OnLButtonDown(Uint16 x, Uint16 y)
{
	if (IsMenuMode()) StartGame();

}

void CMyGame::OnLButtonUp(Uint16 x, Uint16 y)
{
}

void CMyGame::OnRButtonDown(Uint16 x, Uint16 y)
{
}

void CMyGame::OnRButtonUp(Uint16 x, Uint16 y)
{
}

void CMyGame::OnMButtonDown(Uint16 x, Uint16 y)
{
}

void CMyGame::OnMButtonUp(Uint16 x, Uint16 y)
{
}